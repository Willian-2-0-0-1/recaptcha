package com.video.recaptcha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecaptchaApplicationTests {

	@Test
	void contextLoads() {
	}

}
