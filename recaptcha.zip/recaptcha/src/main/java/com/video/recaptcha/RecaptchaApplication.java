package com.video.recaptcha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecaptchaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecaptchaApplication.class, args);
	}

}
