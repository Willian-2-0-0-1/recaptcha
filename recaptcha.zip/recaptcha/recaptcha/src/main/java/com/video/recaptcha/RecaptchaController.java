package com.video.recaptcha;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.HashMap;
import java.util.Map;
@CrossOrigin(origins = "*") // Permite todas as origens (para testes)

@RestController
@RequestMapping("/api/recaptcha")
public class RecaptchaController {

    @Value("${recaptcha.siteKey}")
    private String recaptchaSiteKey;

    @Value("${recaptcha.apiKey}")
    private String recaptchaApiKey;

    @Value("${recaptcha.projectId}")
    private String projectId;

    private final RestTemplate restTemplate = new RestTemplate();

    @PostMapping("/validate")
    public ResponseEntity<Map<String, Object>> validateRecaptcha(@RequestParam("token") String token) {
        String url = "https://recaptchaenterprise.googleapis.com/v1/projects/" + projectId + "/assessments?key=" + recaptchaApiKey;

        // Criando o corpo da requisição
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("event", Map.of(
                "token", token,
                "siteKey", recaptchaSiteKey,
                "expectedAction", "transaction"  // Ajuste conforme necessário
        ));

        //Define que a requisição que será enviada no formato JSON.
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, Map.class);

            if (response.getBody() != null && response.getBody().containsKey("riskAnalysis")) {
                Map<String, Object> riskAnalysis = (Map<String, Object>) response.getBody().get("riskAnalysis");
                double score = (double) riskAnalysis.get("score");
                boolean isHuman = score >=0.7; // Define um score mínimo aceitável

                Map<String, Object> result = new HashMap<>();
                result.put("score", score);
                result.put("isHuman", isHuman);
                result.put("reasons", riskAnalysis.get("reasons")); // Motivos do score

                return ResponseEntity.ok(result);
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Erro Interno: " + e.getMessage()));
        }

        return ResponseEntity.badRequest().body(Map.of("error", "Requisição Inválida"));
    }
}
